1) Find your VS install directory. Typically: "C:\Program Files (x86)\Microsoft Visual Studio\[VERSION]\Enterprise" or similar.
2) From there, navigate to .\MSBuild\Microsoft\VisualStudio\v15.0\AppxPackage\
3) Replace the "x64" and "x86" folders and their contents with the ones in this .zip
4) You shouldn't have to restart VS, but if you continue to see the error it may be necessary.